package com.example.calci

object ExpressionEvaluator {
    fun evaluate(expression: String): Double {
        // Split the expression into operands and operator
        val parts = expression.split(" ")
        val operand1 = parts[0].toDouble()
        val operator = parts[1]
        val operand2 = parts[2].toDouble()

        // Perform the operation based on the operator
        return when (operator) {
            "+" -> operand1 + operand2
            "-" -> operand1 - operand2
            "*" -> operand1 * operand2
            "/" -> operand1 / operand2
            "%" -> operand1 % operand2
            else -> throw IllegalArgumentException("Invalid operator")
        }
    }
}
