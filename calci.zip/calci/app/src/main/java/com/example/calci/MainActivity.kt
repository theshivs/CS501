package com.example.calci

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.exp

class MainActivity : AppCompatActivity() {
    private var resultTextView: TextView? = null
    private var expression = ""
    private lateinit var decimalButton: Button;
    private var isDecimalAllowed = true;
    var init:Boolean = true;


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        resultTextView = findViewById(R.id.resultTextView)

        // Set click listeners for number buttons
        val numberButtonIds = intArrayOf(
            R.id.button0, R.id.button1, R.id.button2, R.id.button3, R.id.button4,
            R.id.button5, R.id.button6, R.id.button7, R.id.button8, R.id.button9
        )
        for (id in numberButtonIds) {
            val button = findViewById<Button>(id)
            button.setOnClickListener { v ->
                val clickedButton = v as Button
                val buttonText = clickedButton.text.toString()
                if(init){
                    expression = buttonText
                    resultTextView!!.text = expression
                    init = false
                }
                else {
                    expression += buttonText
                    resultTextView!!.text = expression
                }

            }
        }
        decimalButton = findViewById(R.id.buttonDecimal)
        decimalButton.setOnClickListener {
            if(isDecimalAllowed) {
                expression += "."
                resultTextView!!.text = expression
                isDecimalAllowed = false;
            }
        }
        val clearButton = findViewById<Button>(R.id.buttonClear)
        clearButton.setOnClickListener {
            expression = ""
            resultTextView!!.text = expression
            isDecimalAllowed = true;
        }

        // Set click listeners for operation buttons
        val operationButtonIds = intArrayOf(
            R.id.buttonAdd, R.id.buttonMinus, R.id.buttonMultiply,
            R.id.buttonDivide, R.id.buttonSqrt
        )
        for (id in operationButtonIds) {
            val button = findViewById<Button>(id)
            button.setOnClickListener { v ->
                val operation = (v as Button).text.toString()
                if(init){
                    expression = operation
                    resultTextView!!.text = expression
                    init = false
                }
                else {
                    expression += operation
                    resultTextView!!.text = expression
                }
                isDecimalAllowed = true;
            }
        }

        // Set click listener for equals button
        val equalsButton = findViewById<Button>(R.id.buttonEquals)
        equalsButton.setOnClickListener {
            calculateResult()
            isDecimalAllowed = true
        }
    }

    private fun calculateResult() {
        if (expression.isEmpty()) {
            Toast.makeText(this@MainActivity, "Please enter an expression", Toast.LENGTH_SHORT).show()
            return;
        }

        val result = performOperation(expression)
        if(result == 0.0){
            resultTextView!!.text = ""
        }else{
            resultTextView!!.text = result.toString()
        }

        expression = result.toString()
    }

    private fun performOperation(expression: String): Double {
        var result = 0.0
        Log.d("-------------", "performOperation: "+expression)

        if(expression.startsWith("sqrt")){
            //expression: sqrt9 => 3.0 + 10 => 13.0
            var num = expression.substring(4).toDouble()
            result = Math.sqrt(num)
            init = false
            return result
        }
        // Find the index where the operation occurs
        val operatorIndex = expression.indexOfAny(charArrayOf('+', '-', '*', '/', '%'))

        // Ensure the operator is found and not at the start or end of the expression
        if (operatorIndex != -1 && operatorIndex > 0 && operatorIndex < expression.length - 1) {
            // Extract operation and operands from the expression
            val operation = expression[operatorIndex].toString()
            val operand1 = expression.substring(0, operatorIndex).toDouble()
            val operand2 = expression.substring(operatorIndex + 1).toDouble()

            // Perform the operation, checking for division by zero
            if (operation == "/" || operation == "%") {
                if (operand2 != 0.0) {
                    // Perform the operation
                    init = false
                    when (operation) {
                        "/" -> result = operand1 / operand2
                        "%" -> result = operand1 % operand2
                    }
                } else {
                    // Notify the user about division by zero
                    Toast.makeText(this@MainActivity, "Division by zero is not allowed", Toast.LENGTH_SHORT).show()
                    init = true
                }
            } else {
                init = false
                // For other operations, perform normally
                when (operation) {
                    "+" -> result = operand1 + operand2
                    "-" -> result = operand1 - operand2
                    "*" -> result = operand1 * operand2
                }
            }
        } else {
            // Invalid expression
            Toast.makeText(this@MainActivity, "Invalid expression", Toast.LENGTH_SHORT).show()
            init = true
        }

        return result
    }
}
