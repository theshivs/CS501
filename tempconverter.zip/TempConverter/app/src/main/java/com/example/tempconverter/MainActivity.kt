package com.example.tempconverter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var celsiusSeekBar: SeekBar
    private lateinit var fahrenheitSeekBar: SeekBar
    private lateinit var celsiusValueTextView: TextView
    private lateinit var fahrenheitValueTextView: TextView
    private lateinit var messageTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        celsiusSeekBar = findViewById(R.id.celsiusSeekBar)
        fahrenheitSeekBar = findViewById(R.id.fahrenheitSeekBar)
        celsiusValueTextView = findViewById(R.id.celsiusValueTextView)
        fahrenheitValueTextView = findViewById(R.id.fahrenheitValueTextView)
        messageTextView = findViewById(R.id.messageTextView)

        celsiusSeekBar.max = 100
        fahrenheitSeekBar.max = 212

        celsiusSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val fahrenheitValue = celsiusToFahrenheit(progress)
                fahrenheitSeekBar.progress = fahrenheitValue
                updateMessage(progress)
                celsiusValueTextView.text = "$progress°C"
                fahrenheitValueTextView.text = "$fahrenheitValue°F"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}

            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        celsiusSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val fahrenheitValue = celsiusToFahrenheit(progress)
                fahrenheitSeekBar.progress = fahrenheitValue
                updateMessage(progress)
                celsiusValueTextView.text = "$progress°C"
                fahrenheitValueTextView.text = "$fahrenheitValue°F"

                if (progress == 0) {
                    fahrenheitSeekBar.isEnabled = true
                } else {
                    fahrenheitSeekBar.isEnabled = false
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}

            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        fahrenheitSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val celsiusValue = fahrenheitToCelsius(progress)
                updateMessage(celsiusValue)
                if (progress < 32 && !fromUser) {
                    seekBar.progress = 32 // Snap back to 32°F
                    fahrenheitValueTextView.text = "32°F"
                    celsiusValueTextView.text = "0°C"
                } else {
                    fahrenheitValueTextView.text = "$progress°F"
                    celsiusValueTextView.text = "$celsiusValue°C"
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                    if (seekBar.progress < 32) {
                        seekBar.progress = 32 // Snap back when released below 32
                    }
            }
        })


    }

    private fun celsiusToFahrenheit(celsius: Int): Int {
        return (celsius * 1.8 + 32).toInt()
    }

    private fun fahrenheitToCelsius(fahrenheit: Int): Int {
        return ((fahrenheit - 32) / 1.8).toInt()
    }

    private fun updateMessage(celsius: Int) {
        if (celsius <= 20) {
            messageTextView.setText("I wish it were warmer.")
        } else {
            messageTextView.setText("I wish it were colder.")
        }
    }
}
