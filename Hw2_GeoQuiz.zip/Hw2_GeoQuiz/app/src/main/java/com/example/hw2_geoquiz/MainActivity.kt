package com.example.hw2_geoquiz

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var question: TextView
    private lateinit var correct_answer: TextView
    private lateinit var wrong_answer: TextView

    val questions = arrayOf("Canberra is the capital of Australia.",
        "The Pacific Ocean is larger than the Atlantic Ocean.",
        "The Suez Canal connects the Red Sea and the Indian Ocean.",
        "The source of the Nile River is in Egypt.",
        "The Amazon River is the longest river in the Americas.",
        "Lake Baikal is the world\\'s oldest and deepest freshwater lake.")
    val answers = arrayOf(true,true,false,false,true,true)
    val totalQuestion = questions.size
    var currentQuestion = 0;
    var selectedAnswer = ""



    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        question = findViewById(R.id.question)
        trueButton = findViewById(R.id.true_button)
        falseButton = findViewById(R.id.false_button)
        correct_answer = findViewById(R.id.correct_answer)
        wrong_answer = findViewById(R.id.wrong_answer)

        trueButton.setOnClickListener { view: View ->
            checkAnswer("true");
        }

        falseButton.setOnClickListener { view: View ->
            checkAnswer("false")
        }

        loadNewQuestion()
    }

    private fun checkAnswer(s: String) {
        selectedAnswer = s;
        if(selectedAnswer.equals(answers[currentQuestion].toString())){
            Toast.makeText(this, "Correct Answer", Toast.LENGTH_SHORT).show();
            correct_answer.text = "Correct answers: "+(correct_answer.text.split(':')[1].trim().toInt() + 1).toString()
        }else{
            Toast.makeText(this, "Wrong Answer", Toast.LENGTH_SHORT).show();
            wrong_answer.text = "Wrong answers: "+(wrong_answer.text.split(':')[1].trim().toInt() + 1).toString()
        }
        currentQuestion++;
        loadNewQuestion();
    }

    private fun loadNewQuestion() {
        if(currentQuestion == questions.size){
            Toast.makeText(this, "Quiz is finished", Toast.LENGTH_SHORT).show();
            currentQuestion = 0;
        }
        question.text = questions[currentQuestion]
    }
}